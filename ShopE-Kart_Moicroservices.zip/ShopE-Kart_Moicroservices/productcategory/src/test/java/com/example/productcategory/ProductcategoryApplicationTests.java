package com.example.productcategory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductcategoryApplicationTests {

	@Test
	void contextLoads() {
	}

}

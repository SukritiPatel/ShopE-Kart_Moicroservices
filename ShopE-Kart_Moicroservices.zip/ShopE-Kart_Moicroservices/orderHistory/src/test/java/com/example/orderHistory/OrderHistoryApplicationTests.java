package com.example.orderHistory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderHistoryApplicationTests {

	@Test
	void contextLoads() {
	}

}

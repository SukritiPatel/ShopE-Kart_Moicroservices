package com.example.orderHistory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
public class OrderHistoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderHistoryApplication.class, args);
	}

}
